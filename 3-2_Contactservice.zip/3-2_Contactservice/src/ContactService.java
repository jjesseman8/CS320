import java.util.ArrayList;
import java.util.List;

public class ContactService {
    private final List<Contact> contacts;

    public ContactService() {
        this.contacts = new ArrayList<>();
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public void deleteContact(String contactID) {
        contacts.removeIf(contact -> contact.getContactID().equals(contactID));
    }

    public void updateContact(String contactID, String field, String value) {
        for (Contact contact : contacts) {
            if (contact.getContactID().equals(contactID)) {
                switch (field) {
                    case "firstName":
                        contact.setFirstName(value);
                        break;
                    case "lastName":
                        contact.setLastName(value);
                        break;
                    case "phone":
                        contact.setPhone(value);
                        break;
                    case "address":
                        contact.setAddress(value);
                        break;
                    default:
                        throw new IllegalArgumentException("Invalid field: " + field);
                }
                break;
            }
        }
    }

    public List<Contact> getContacts() {
        return contacts;
    }
}

