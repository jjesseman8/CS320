import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "Sample Address");

        contactService.addContact(contact);

        // Assert that the contact was added successfully
        assertEquals(1, contactService.getContacts().size());
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "Sample Address");

        // Add the contact to the contact service
        contactService.addContact(contact);

        // Delete the contact using its contactID
        contactService.deleteContact(contact.getContactID());

        // Assert that the contact is no longer present
        assertEquals(0, contactService.getContacts().size());
    }
}

